import React from 'react';
import { CalendarDays, Image, Megaphone, MessageCircle, Users, Clock3, ArrowRight } from 'lucide-react';
import { CalendarEvent, HistoryMemory, MediaItem, NewsItem, User } from '../../types';

interface HomeTabProps {
  currentUser: User;
  users: User[];
  news: NewsItem[];
  media: MediaItem[];
  events: CalendarEvent[];
  memories: HistoryMemory[];
  onNavigate: (tab: 'media' | 'news' | 'calendar' | 'share' | 'chat' | 'history') => void;
}

export const HomeTab: React.FC<HomeTabProps> = ({
  currentUser, users, news, media, events, memories, onNavigate,
}) => {
  const approved = users.filter(u => u.status === 'approved');
  const upcoming = [...events]
    .filter(e => e.date >= new Date().toISOString().slice(0, 10))
    .sort((a,b) => `${a.date}${a.time || ''}`.localeCompare(`${b.date}${b.time || ''}`))[0];

  const cards = [
    { label: 'Family members', value: approved.length, icon: Users, tab: 'chat' as const },
    { label: 'Family news', value: news.length, icon: Megaphone, tab: 'news' as const },
    { label: 'Memories & media', value: media.length + memories.length, icon: Image, tab: 'media' as const },
    { label: 'Events', value: events.length, icon: CalendarDays, tab: 'calendar' as const },
  ];

  return (
    <div className="space-y-5 pb-20">
      <section className="rounded-[2rem] bg-[#22244A] text-white p-6 sm:p-8 shadow-xl overflow-hidden relative">
        <div className="absolute -right-16 -top-20 w-56 h-56 rounded-full bg-[#E2B04A]/15 blur-2xl" />
        <div className="relative">
          <p className="text-xs uppercase tracking-[0.2em] text-[#E2B04A] font-bold">BMF Family Hub</p>
          <h2 className="font-heading text-3xl sm:text-4xl font-extrabold mt-2">Welcome back, {currentUser.fullName.split(' ')[0]}.</h2>
          <p className="text-sm text-slate-300 mt-2 max-w-xl">One private place for family news, memories, events, conversations and shared moments.</p>
          <div className="mt-5 flex flex-wrap gap-2">
            <span className="px-3 py-1.5 rounded-full bg-white/10 text-xs">Since 2021</span>
            <span className="px-3 py-1.5 rounded-full bg-emerald-500/15 text-emerald-200 text-xs">Private family space</span>
          </div>
        </div>
      </section>

      <section className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {cards.map(({label,value,icon:Icon,tab}) => (
          <button key={label} onClick={() => onNavigate(tab)} className="text-left bg-white dark:bg-[#1a1b35] rounded-2xl border border-slate-100 dark:border-slate-800 p-4 shadow-sm hover:-translate-y-0.5 transition">
            <div className="w-9 h-9 rounded-xl bg-[#E2B04A]/15 text-[#B78318] dark:text-[#E2B04A] flex items-center justify-center"><Icon className="w-4 h-4"/></div>
            <p className="text-2xl font-extrabold mt-3">{value}</p>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">{label}</p>
          </button>
        ))}
      </section>

      <section className="grid lg:grid-cols-2 gap-4">
        <div className="bg-white dark:bg-[#1a1b35] rounded-2xl border border-slate-100 dark:border-slate-800 p-5">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs font-bold uppercase tracking-wider text-[#B78318] dark:text-[#E2B04A]">Next family event</p>
              <h3 className="font-heading font-bold text-xl mt-1">{upcoming?.title || 'No upcoming events'}</h3>
            </div>
            <CalendarDays className="w-5 h-5 text-[#E2B04A]" />
          </div>
          {upcoming ? (
            <p className="text-sm text-slate-500 dark:text-slate-400 mt-3">{upcoming.date}{upcoming.time ? ` · ${upcoming.time}` : ''}</p>
          ) : <p className="text-sm text-slate-500 mt-3">Create the first family event from Calendar.</p>}
          <button onClick={() => onNavigate('calendar')} className="mt-4 text-xs font-bold text-[#B78318] dark:text-[#E2B04A] flex items-center gap-1">Open calendar <ArrowRight className="w-3.5 h-3.5"/></button>
        </div>

        <div className="bg-white dark:bg-[#1a1b35] rounded-2xl border border-slate-100 dark:border-slate-800 p-5">
          <div className="flex items-center gap-2"><Clock3 className="w-5 h-5 text-[#E2B04A]"/><p className="text-xs font-bold uppercase tracking-wider text-[#B78318] dark:text-[#E2B04A]">Latest family news</p></div>
          <h3 className="font-heading font-bold text-xl mt-2">{news[0]?.title || 'Welcome to the family hub'}</h3>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-2 line-clamp-2">{news[0]?.message || 'Your family announcements will appear here.'}</p>
          <button onClick={() => onNavigate('news')} className="mt-4 text-xs font-bold text-[#B78318] dark:text-[#E2B04A] flex items-center gap-1">View all news <ArrowRight className="w-3.5 h-3.5"/></button>
        </div>
      </section>

      <section className="grid grid-cols-2 gap-3">
        <button onClick={() => onNavigate('chat')} className="rounded-2xl bg-[#22244A] text-white p-4 text-left hover:bg-[#2c2f60] transition">
          <MessageCircle className="w-5 h-5 text-[#E2B04A]"/>
          <p className="font-bold mt-3">Family Chat</p>
          <p className="text-xs text-slate-300 mt-1">Stay connected in real time.</p>
        </button>
        <button onClick={() => onNavigate('history')} className="rounded-2xl bg-[#E2B04A] text-[#22244A] p-4 text-left hover:brightness-105 transition">
          <Clock3 className="w-5 h-5"/>
          <p className="font-bold mt-3">Family History</p>
          <p className="text-xs opacity-75 mt-1">Keep the story alive for the next generation.</p>
        </button>
      </section>
    </div>
  );
};
