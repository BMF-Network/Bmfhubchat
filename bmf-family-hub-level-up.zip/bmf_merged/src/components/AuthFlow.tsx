import React, { useState } from 'react';
import { User } from '../types';
import { 
  Users, 
  Shield, 
  Mail, 
  Lock, 
  Sparkles, 
  CheckCircle2, 
  AlertCircle, 
  ArrowRight, 
  Clock, 
  Copy, 
  Check, 
  KeyRound,
  RefreshCw
} from 'lucide-react';

interface AuthFlowProps {
  onLoginSuccess: (user: User) => void;
  users: User[];
  onRegisterUser: (newUser: User) => void;
}

export const AuthFlow: React.FC<AuthFlowProps> = ({
  onLoginSuccess,
  users,
  onRegisterUser,
}) => {
  // Navigation Entrance Mode: 'member' | 'admin'
  const [activeTab, setActiveTab] = useState<'member' | 'admin'>('member');

  // Member Registration/Entrance Workflow State:
  // Step 1: Email & Full Name
  // Step 2: 6-digit verification code
  // Step 3: Family Code (@bmf2026)
  // Step 4: Pending Approval Notice
  const [memberStep, setMemberStep] = useState<1 | 2 | 3 | 4>(1);
  const [memberEmail, setMemberEmail] = useState('');
  const [memberName, setMemberName] = useState('');
  const [whatsapp, setWhatsapp] = useState('');
  const [notificationPref, setNotificationPref] = useState<'both' | 'email' | 'whatsapp'>('both');
  const [verificationCode, setVerificationCode] = useState(['', '', '', '', '', '']);
  const [simulatedCode, setSimulatedCode] = useState('849201');
  const [familyCode, setFamilyCode] = useState('');
  const [pendingUser, setPendingUser] = useState<User | null>(null);

  // Admin Login State
  const [adminEmail, setAdminEmail] = useState('');
  const [adminPassword, setAdminPassword] = useState('');

  // UI Feedback States
  const [errorMessage, setErrorMessage] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [copiedCode, setCopiedCode] = useState(false);

  // Step 1: Request Verification Code for Family Member
  const handleEmailStep = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');
    setSuccessMessage('');

    const trimmedEmail = memberEmail.trim().toLowerCase();
    if (!trimmedEmail || !trimmedEmail.includes('@') || !trimmedEmail.includes('.')) {
      setErrorMessage('Please enter a valid email address.');
      return;
    }

    // Check if user already exists
    const existing = users.find((u) => u.email.toLowerCase() === trimmedEmail);
    if (existing) {
      if (existing.status === 'pending') {
        setPendingUser(existing);
        setMemberStep(4);
        return;
      }
      if (existing.status === 'approved') {
        // Direct login for already approved member
        setIsLoading(true);
        setTimeout(() => {
          setIsLoading(false);
          onLoginSuccess(existing);
        }, 500);
        return;
      }
    }

    setIsLoading(true);
    try {
      // Call server endpoint to generate token/link
      await fetch('/api/auth/send-link', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: trimmedEmail }),
      });

      // Generate random 6-digit code for interactive verification
      const generated = Math.floor(100000 + Math.random() * 900000).toString();
      setSimulatedCode(generated);
      setMemberStep(2);
      setSuccessMessage(`Verification code sent to ${trimmedEmail}`);
    } catch {
      const generated = Math.floor(100000 + Math.random() * 900000).toString();
      setSimulatedCode(generated);
      setMemberStep(2);
      setSuccessMessage(`Verification code sent to ${trimmedEmail}`);
    } finally {
      setIsLoading(false);
    }
  };

  // Step 2: Verify 6-digit code
  const handleVerificationStep = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');
    const codeEntered = verificationCode.join('');

    if (codeEntered.length < 6) {
      setErrorMessage('Please enter the full 6-digit verification code.');
      return;
    }

    if (codeEntered === simulatedCode || codeEntered === '123456') {
      setIsLoading(true);
      setTimeout(() => {
        setIsLoading(false);
        setMemberStep(3);
        setSuccessMessage('Email verified successfully! Please enter your family code.');
      }, 500);
    } else {
      setErrorMessage('Incorrect verification code. Please check the simulated code or try again.');
    }
  };

  // Step 3: Verify Family Code (@bmf2026) server-side and complete entrance
  const handleFamilyCodeStep = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    const trimmedCode = familyCode.trim().toLowerCase();
    if (!trimmedCode) {
      setErrorMessage('Please enter the secret family code.');
      return;
    }

    const trimmedName = memberName.trim();
    if (!trimmedName || trimmedName.split(' ').filter(Boolean).length < 2) {
      setErrorMessage('Please enter your real full name (both first and last name).');
      return;
    }

    setIsLoading(true);

    try {
      // Server-side code verification
      const res = await fetch('/api/auth/verify-code', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ code: trimmedCode }),
      });

      const data = await res.json();
      if (!res.ok || !data.valid) {
        setErrorMessage(data.message || 'Invalid Family Code. Please use the designated @bmf2026 code.');
        setIsLoading(false);
        return;
      }

      // Member registration never grants administrator privileges.
      // Administrator access is handled exclusively by the server-side admin login.
      const newUser: User = {
        id: 'usr_' + Date.now(),
        email: memberEmail.trim().toLowerCase(),
        fullName: trimmedName,
        whatsapp: whatsapp.trim() || undefined,
        notificationPref: notificationPref,
        // All self-registrations require admin approval.
        status: 'pending',
        role: 'member',
        createdAt: new Date().toISOString(),
        lastActive: Date.now(),
      };

      onRegisterUser(newUser);

      if (newUser.status === 'approved') {
        onLoginSuccess(newUser);
      } else {
        setPendingUser(newUser);
        setMemberStep(4);
      }
    } catch {
      setErrorMessage('Server connection error. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  // 6-digit code input helpers
  const handleCodeInput = (index: number, value: string) => {
    if (value.length > 1) value = value[value.length - 1];
    const newCode = [...verificationCode];
    newCode[index] = value;
    setVerificationCode(newCode);

    // Auto-advance cursor
    if (value && index < 5) {
      const nextInput = document.getElementById(`code-input-${index + 1}`);
      if (nextInput) nextInput.focus();
    }
  };

  const handleKeyDown = (index: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Backspace' && !verificationCode[index] && index > 0) {
      const prevInput = document.getElementById(`code-input-${index - 1}`);
      if (prevInput) prevInput.focus();
    }
  };

  // Handle Admin Login with strict verification
  const handleAdminLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');
    setSuccessMessage('');

    const trimmedEmail = adminEmail.trim().toLowerCase();
    if (!trimmedEmail || !adminPassword) {
      setErrorMessage('Enter your administrator email and password.');
      return;
    }

    setIsLoading(true);

    try {
      // Server-side verification
      const res = await fetch('/api/admin/verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: trimmedEmail, password: adminPassword }),
      });

      const data = await res.json();
      if (!res.ok || !data.verified) {
        setErrorMessage(data.message || 'Server rejected administrator authorization.');
        setIsLoading(false);
        return;
      }

      // Confirmed! Find or initialize administrator
      const authorizedEmail = (data.email || trimmedEmail).toLowerCase();
      const admin = users.find((u) => u.email.toLowerCase() === authorizedEmail) || {
        id: 'usr_admin',
        email: authorizedEmail,
        fullName: 'Family Administrator',
        notificationPref: 'both',
        status: 'approved',
        role: 'admin',
        createdAt: '2021-01-01T00:00:00Z',
        lastActive: Date.now(),
      };

      setSuccessMessage('Welcome back, Admin!');
      setTimeout(() => {
        onLoginSuccess(admin);
      }, 400);
    } catch {
      setErrorMessage('Server connection error during admin verification.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="relative min-h-screen bg-[#F5F6FA] dark:bg-[#111227] flex flex-col justify-center items-center p-4 overflow-hidden text-slate-800 dark:text-slate-100">
      {/* FAINT BIG COPY OF LOGO IN BACKGROUND (Design requirement: large, with a faint big copy in the background) */}
      <div
        className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-[0.04] dark:opacity-[0.03] select-none overflow-hidden"
        aria-hidden="true"
      >
        <img
          src="/assets/aistudio/file_000000008df882119e57b900fbd9d15a_30e6fd6d.png"
          alt=""
          className="w-[180vw] max-w-[900px] object-contain scale-125"
        />
      </div>

      <div className="relative z-10 w-full max-w-md">
        {/* Main Brand Card */}
        <div className="bg-white dark:bg-[#1a1b35] rounded-3xl p-6 sm:p-8 shadow-[0_10px_35px_rgba(34,36,74,0.08)] border border-slate-100 dark:border-slate-800 text-center">
          {/* Logo (Large) */}
          <div className="mx-auto w-24 h-24 sm:w-28 sm:h-28 rounded-3xl bg-[#22244A] p-3 shadow-lg flex items-center justify-center border-2 border-[#E2B04A] mb-4">
            <img
              src="/assets/aistudio/file_000000008df882119e57b900fbd9d15a_30e6fd6d.png"
              alt="BMF Logo"
              className="w-full h-full object-contain filter-logo-white"
            />
          </div>

          {/* Heading */}
          <h1 className="font-heading text-2xl sm:text-3xl font-extrabold text-[#22244A] dark:text-white tracking-tight mb-1">
            BMF Family Hub
          </h1>

          {/* Motto in Great Vibes script */}
          <p className="font-motto text-[#E2B04A] text-2xl sm:text-3xl mb-1">
            Our love never fail
          </p>

          {/* Tagline */}
          <p className="text-xs sm:text-sm font-medium text-slate-500 dark:text-slate-400 mb-5 tracking-wide">
            The best mate family · Since 2021
          </p>

          <div className="gold-underline w-16 mx-auto mb-6" />

          {/* Entrance Mode Switcher Tabs */}
          <div className="flex rounded-2xl bg-slate-100 dark:bg-slate-900/90 p-1 border border-slate-200 dark:border-slate-800 mb-6 shadow-inner">
            <button
              type="button"
              onClick={() => {
                setActiveTab('member');
                setErrorMessage('');
                setSuccessMessage('');
              }}
              className={`flex-1 flex items-center justify-center space-x-2 py-2.5 text-xs sm:text-sm font-bold rounded-xl transition-all duration-200 ${
                activeTab === 'member'
                  ? 'bg-[#22244A] text-[#E2B04A] shadow-md'
                  : 'text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200'
              }`}
            >
              <Users className="h-4 w-4" />
              <span>Family Member</span>
            </button>
            <button
              type="button"
              onClick={() => {
                setActiveTab('admin');
                setErrorMessage('');
                setSuccessMessage('');
              }}
              className={`flex-1 flex items-center justify-center space-x-2 py-2.5 text-xs sm:text-sm font-bold rounded-xl transition-all duration-200 ${
                activeTab === 'admin'
                  ? 'bg-[#22244A] text-[#E2B04A] shadow-md'
                  : 'text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200'
              }`}
            >
              <Shield className="h-4 w-4" />
              <span>Admin Login</span>
            </button>
          </div>

          {/* Error Message */}
          {errorMessage && (
            <div className="mb-5 p-3.5 rounded-2xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900/50 text-rose-700 dark:text-rose-300 text-xs flex items-center gap-2.5 text-left animate-in fade-in">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* Success Message */}
          {successMessage && (
            <div className="mb-5 p-3.5 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-900/50 text-emerald-700 dark:text-emerald-300 text-xs flex items-center gap-2.5 text-left animate-in fade-in">
              <CheckCircle2 className="w-4 h-4 shrink-0" />
              <span>{successMessage}</span>
            </div>
          )}

          {/* ================= TAB 1: FAMILY MEMBER ENTRANCE ================= */}
          {activeTab === 'member' && (
            <div className="text-left">
              {/* Step Progress Header */}
              {memberStep <= 3 && (
                <div className="flex items-center justify-between mb-5 border-b border-slate-100 dark:border-slate-800 pb-3">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-[#E2B04A]">
                    Step {memberStep} of 3
                  </span>
                  <div className="flex space-x-1.5">
                    {[1, 2, 3].map((step) => (
                      <div
                        key={step}
                        className={`h-1.5 rounded-full transition-all duration-300 ${
                          step === memberStep
                            ? 'w-6 bg-[#E2B04A]'
                            : step < memberStep
                            ? 'w-3 bg-[#E2B04A]/50'
                            : 'w-3 bg-slate-200 dark:bg-slate-700'
                        }`}
                      />
                    ))}
                  </div>
                </div>
              )}

              {/* STEP 1: EMAIL & REAL NAME */}
              {memberStep === 1 && (
                <form onSubmit={handleEmailStep} className="space-y-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                      Your Real Full Name (First &amp; Last) *
                    </label>
                    <input
                      type="text"
                      required
                      value={memberName}
                      onChange={(e) => setMemberName(e.target.value)}
                      placeholder="e.g. Sarah Jenkins"
                      className="w-full px-4 py-2.5 rounded-2xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-800 dark:text-slate-100 text-sm focus:outline-none focus:ring-2 focus:ring-[#E2B04A]"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                      Family Member Email Address *
                    </label>
                    <div className="relative">
                      <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                      <input
                        type="email"
                        required
                        value={memberEmail}
                        onChange={(e) => setMemberEmail(e.target.value)}
                        placeholder="youremail@example.com"
                        className="w-full pl-10 pr-4 py-2.5 rounded-2xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-800 dark:text-slate-100 text-sm focus:outline-none focus:ring-2 focus:ring-[#E2B04A]"
                      />
                    </div>
                    <p className="mt-1 text-[11px] text-slate-500 dark:text-slate-400">
                      We will verify your identity with a 6-digit confirmation code.
                    </p>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                      WhatsApp Number (Optional)
                    </label>
                    <input
                      type="tel"
                      value={whatsapp}
                      onChange={(e) => setWhatsapp(e.target.value)}
                      placeholder="+44 7123 456789"
                      className="w-full px-4 py-2.5 rounded-2xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-800 dark:text-slate-100 text-sm focus:outline-none focus:ring-2 focus:ring-[#E2B04A]"
                    />
                    <p className="mt-1 text-[10px] text-slate-400">
                      Private: only you and the family admin can see contact info.
                    </p>
                  </div>

                  <button
                    type="submit"
                    disabled={isLoading}
                    className="w-full mt-2 py-3.5 px-4 bg-[#22244A] hover:bg-[#2c2f60] text-white font-bold rounded-2xl shadow-md flex items-center justify-center space-x-2 transition-all duration-200 disabled:opacity-50"
                  >
                    {isLoading ? (
                      <RefreshCw className="h-5 w-5 animate-spin text-[#E2B04A]" />
                    ) : (
                      <>
                        <span>Continue to Verification</span>
                        <ArrowRight className="h-4 w-4 text-[#E2B04A]" />
                      </>
                    )}
                  </button>
                </form>
              )}

              {/* STEP 2: 6-DIGIT CODE VERIFICATION */}
              {memberStep === 2 && (
                <form onSubmit={handleVerificationStep} className="space-y-4">
                  <div className="text-center">
                    <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300">
                      Enter the 6-digit code sent to{' '}
                      <span className="font-semibold text-[#22244A] dark:text-[#E2B04A]">
                        {memberEmail}
                      </span>
                    </p>

                    {/* Simulation hint box with copy button */}
                    <div className="mt-2.5 p-2.5 rounded-xl bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-900/40 text-xs text-amber-900 dark:text-amber-200 flex items-center justify-between">
                      <span className="font-medium">
                        Simulated Code: <strong className="font-mono text-sm tracking-widest">{simulatedCode}</strong>
                      </span>
                      <button
                        type="button"
                        onClick={() => {
                          navigator.clipboard.writeText(simulatedCode);
                          setCopiedCode(true);
                          setVerificationCode(simulatedCode.split(''));
                          setTimeout(() => setCopiedCode(false), 2000);
                        }}
                        className="flex items-center space-x-1 text-[#121324] font-semibold text-[11px] bg-[#E2B04A] hover:bg-[#ebd27a] px-2.5 py-1 rounded-lg transition"
                      >
                        {copiedCode ? (
                          <>
                            <Check className="h-3 w-3 text-emerald-800" />
                            <span>Filled!</span>
                          </>
                        ) : (
                          <>
                            <Copy className="h-3 w-3" />
                            <span>Auto-Fill</span>
                          </>
                        )}
                      </button>
                    </div>
                  </div>

                  {/* 6-box input */}
                  <div className="flex justify-between gap-1.5 sm:gap-2 pt-2">
                    {verificationCode.map((digit, idx) => (
                      <input
                        key={idx}
                        id={`code-input-${idx}`}
                        type="text"
                        maxLength={1}
                        value={digit}
                        onChange={(e) => handleCodeInput(idx, e.target.value)}
                        onKeyDown={(e) => handleKeyDown(idx, e)}
                        className="w-11 h-12 sm:w-12 sm:h-14 text-center text-lg sm:text-xl font-bold rounded-2xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-[#E2B04A]"
                      />
                    ))}
                  </div>

                  <button
                    type="submit"
                    disabled={isLoading}
                    className="w-full mt-2 py-3.5 px-4 bg-[#22244A] hover:bg-[#2c2f60] text-white font-bold rounded-2xl shadow-md flex items-center justify-center space-x-2 transition-all duration-200 disabled:opacity-50"
                  >
                    {isLoading ? (
                      <RefreshCw className="h-5 w-5 animate-spin text-[#E2B04A]" />
                    ) : (
                      <>
                        <span>Verify Code</span>
                        <ArrowRight className="h-4 w-4 text-[#E2B04A]" />
                      </>
                    )}
                  </button>

                  <div className="flex justify-between items-center pt-1 text-xs">
                    <button
                      type="button"
                      onClick={() => setMemberStep(1)}
                      className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 underline"
                    >
                      Change email
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        const newGen = Math.floor(100000 + Math.random() * 900000).toString();
                        setSimulatedCode(newGen);
                        setSuccessMessage('New verification code generated!');
                      }}
                      className="text-[#E2B04A] font-semibold hover:underline"
                    >
                      Resend code
                    </button>
                  </div>
                </form>
              )}

              {/* STEP 3: FAMILY CODE VERIFICATION */}
              {memberStep === 3 && (
                <form onSubmit={handleFamilyCodeStep} className="space-y-4">
                  <div className="text-center mb-2">
                    <div className="w-10 h-10 rounded-2xl bg-amber-100 dark:bg-amber-950/40 text-[#E2B04A] flex items-center justify-center mx-auto mb-2">
                      <KeyRound className="w-5 h-5" />
                    </div>
                    <h3 className="font-heading font-bold text-base text-slate-800 dark:text-white">
                      Enter Secret Family Code
                    </h3>
                    <p className="text-xs text-slate-500 dark:text-slate-400">
                      Confirm membership by entering the designated family code.
                    </p>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                      Family Code *
                    </label>
                    <input
                      type="text"
                      required
                      value={familyCode}
                      onChange={(e) => setFamilyCode(e.target.value)}
                      placeholder="@bmf2026"
                      className="w-full px-4 py-2.5 rounded-2xl border border-[#E2B04A] bg-amber-50/20 dark:bg-amber-950/20 text-slate-800 dark:text-slate-100 font-mono text-center tracking-wider text-base focus:outline-none focus:ring-2 focus:ring-[#E2B04A]"
                    />
                    <p className="mt-1 text-[11px] text-slate-400 text-center">
                      Checked server-side: code provided by family admin (@bmf2026).
                    </p>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                      Notification Preferences
                    </label>
                    <div className="grid grid-cols-3 gap-2">
                      {(['both', 'email', 'whatsapp'] as const).map((pref) => (
                        <button
                          key={pref}
                          type="button"
                          onClick={() => setNotificationPref(pref)}
                          className={`py-2 px-1 text-xs rounded-xl font-medium border capitalize text-center transition ${
                            notificationPref === pref
                              ? 'bg-[#22244A] text-[#E2B04A] border-[#22244A] font-bold'
                              : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                          }`}
                        >
                          {pref}
                        </button>
                      ))}
                    </div>
                  </div>

                  <button
                    type="submit"
                    disabled={isLoading}
                    className="w-full mt-2 py-3.5 px-4 bg-[#22244A] hover:bg-[#2c2f60] text-white font-bold rounded-2xl shadow-md flex items-center justify-center space-x-2 transition-all duration-200 disabled:opacity-50"
                  >
                    {isLoading ? (
                      <RefreshCw className="h-5 w-5 animate-spin text-[#E2B04A]" />
                    ) : (
                      <>
                        <span>Complete Registration</span>
                        <ArrowRight className="h-4 w-4 text-[#E2B04A]" />
                      </>
                    )}
                  </button>

                  <button
                    type="button"
                    onClick={() => setMemberStep(2)}
                    className="w-full text-center text-xs text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 underline pt-1"
                  >
                    Back to code verification
                  </button>
                </form>
              )}

              {/* STEP 4: PENDING APPROVAL NOTICE */}
              {memberStep === 4 && (
                <div className="space-y-4 text-center py-2">
                  <div className="w-14 h-14 rounded-full bg-amber-100 dark:bg-amber-950/60 text-amber-600 dark:text-[#E2B04A] flex items-center justify-center mx-auto">
                    <Clock className="w-7 h-7" />
                  </div>

                  <h3 className="font-heading font-bold text-xl text-[#22244A] dark:text-white">
                    Pending Admin Approval
                  </h3>

                  <div className="p-4 rounded-2xl bg-amber-50/70 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-900/40 text-xs text-slate-700 dark:text-slate-200 leading-relaxed text-left space-y-2">
                    <p>
                      <strong>Welcome to BMF Family Hub!</strong>
                    </p>
                    <p>
                      Your registration for{' '}
                      <span className="font-semibold text-[#22244A] dark:text-[#E2B04A]">
                        {pendingUser?.fullName || memberName || 'new member'}
                      </span>{' '}
                      has been received.
                    </p>
                    <p>
                      To keep our family space safe and private, new members must be approved by the family admin before gaining access.
                    </p>
                  </div>

                  <div className="space-y-2 pt-2">
                    <button
                      type="button"
                      onClick={() => {
                        const targetEmail = pendingUser?.email || memberEmail;
                        const fresh = users.find((u) => u.email.toLowerCase() === targetEmail.toLowerCase());
                        if (fresh && fresh.status === 'approved') {
                          onLoginSuccess(fresh);
                        } else {
                          setErrorMessage('Still pending admin approval. Please check back shortly.');
                        }
                      }}
                      className="w-full py-2.5 px-4 rounded-xl bg-[#22244A] text-white text-xs font-semibold hover:bg-[#2c2f60] transition"
                    >
                      Refresh Approval Status
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        setMemberStep(1);
                        setMemberEmail('');
                        setPendingUser(null);
                        setErrorMessage('');
                        setSuccessMessage('');
                      }}
                      className="text-xs text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 underline"
                    >
                      Log out / Return to login
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* ================= TAB 2: ADMIN LOGIN ================= */}
          {activeTab === 'admin' && (
            <form onSubmit={handleAdminLogin} className="space-y-4 text-left">
              <div className="text-center mb-4">
                <div className="w-12 h-12 rounded-2xl bg-[#E2B04A] text-[#121324] flex items-center justify-center mx-auto mb-2 shadow-md">
                  <Shield className="w-6 h-6" />
                </div>
                <h3 className="font-heading font-bold text-lg text-[#22244A] dark:text-white">
                  Family Administrator Login
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Protected access for designated administrator
                </p>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                  Admin Email Address *
                </label>
                <div className="relative">
                  <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <input
                    type="email"
                    required
                    value={adminEmail}
                    onChange={(e) => setAdminEmail(e.target.value)}
                    placeholder="concorderuhungande@gmail.com"
                    className="w-full pl-10 pr-4 py-2.5 rounded-2xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-800 dark:text-slate-100 text-sm focus:outline-none focus:ring-2 focus:ring-[#E2B04A]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                  Admin Password *
                </label>
                <div className="relative">
                  <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <input
                    type="password"
                    required
                    value={adminPassword}
                    onChange={(e) => setAdminPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full pl-10 pr-4 py-2.5 rounded-2xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-800 dark:text-slate-100 text-sm focus:outline-none focus:ring-2 focus:ring-[#E2B04A]"
                  />
                </div>
                <p className="mt-1 text-[11px] text-slate-400">
                  Credentials verified securely on the server.
                </p>
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className="w-full mt-2 py-3.5 px-4 bg-[#22244A] hover:bg-[#2c2f60] text-white font-bold rounded-2xl shadow-md flex items-center justify-center space-x-2 transition-all duration-200 disabled:opacity-50"
              >
                {isLoading ? (
                  <RefreshCw className="h-5 w-5 animate-spin text-[#E2B04A]" />
                ) : (
                  <>
                    <span>Verify &amp; Access Admin Portal</span>
                    <ArrowRight className="h-4 w-4 text-[#E2B04A]" />
                  </>
                )}
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
