<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://ai.google.dev/static/site-assets/images/share-ais-513315318.png" />
</div>

# Run and deploy your AI Studio app

This contains everything you need to run your app locally.

View your app in AI Studio: https://ai.studio/apps/5ae116e9-de8b-4a3c-b6ae-7cae34078f3f

## Run Locally

**Prerequisites:**  Node.js


1. Install dependencies:
   `npm install`
2. Set the `GEMINI_API_KEY` in [.env.local](.env.local) to your Gemini API key
3. Run the app:
   `npm run dev`


## Level-up release notes

This release consolidates the family experience into one product:
- Added a Home dashboard with family metrics, next event, latest news and quick actions.
- Expanded bottom navigation from six to seven sections.
- Kept Media, News, Calendar, Share, Chat and History as the core family modules.
- Moved admin password and family-code configuration to environment variables for production safety.
- Removed the legacy hard-coded administrator password from the server source.
- Preserved the existing local-first storage and notification architecture.

### Production security
Set `ADMIN_EMAIL`, `ADMIN_PASSWORD`, and `FAMILY_CODE` in the deployment environment. Do not commit real credentials.
